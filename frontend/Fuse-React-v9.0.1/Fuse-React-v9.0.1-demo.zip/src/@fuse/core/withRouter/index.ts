export { default } from './withRouter';
