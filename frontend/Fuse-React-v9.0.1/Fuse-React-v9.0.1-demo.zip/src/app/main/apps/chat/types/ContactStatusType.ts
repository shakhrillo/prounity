/**
 * Contact Status Type
 */
export type ContactStatusType = 'online' | 'do-not-disturb' | 'away' | 'offline';
