/**
 * Contact Attachments Type
 */
export type ContactAttachmentsType = {
	media: string[];
	docs: string[];
	links: string[];
};
