import { ChatListItemType } from './ChatListItemType';

/**
 * Chat List Type
 */
export type ChatListType = ChatListItemType[];
