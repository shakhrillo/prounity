/**
 * Message Type
 */
export type MessageType = {
	id: string;
	contactId: string;
	value: string;
	createdAt: string;
};
