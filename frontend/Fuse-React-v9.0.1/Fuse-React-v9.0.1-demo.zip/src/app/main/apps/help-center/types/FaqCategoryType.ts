/**
 * FaqCategoryType
 */
export type FaqCategoryType = {
	id: string;
	slug: string;
	title: string;
};

/**
 * FaqCategoriesType
 */
export type FaqCategoriesType = FaqCategoryType[];
