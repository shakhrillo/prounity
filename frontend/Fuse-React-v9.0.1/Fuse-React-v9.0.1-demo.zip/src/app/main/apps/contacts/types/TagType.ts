/**
 * Tag Type
 */
export type TagType = {
	id: string;
	title: string;
};

/**
 * Tags Type
 */
export type TagsType = TagType[];
