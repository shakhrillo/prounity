declare module '*.json';
