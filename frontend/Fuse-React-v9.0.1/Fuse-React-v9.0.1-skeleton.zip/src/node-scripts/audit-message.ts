// eslint-disable-next-line no-console
console.log(`**************************************************************
*                                                            *
*  Please Note:                                              *
*                                                            *
*  There can be vulnerabilities that are related to the      *
*  only development environment.                             *
*                                                            *
*  So these do not pose a risk to production.                *
*                                                            *
*  Its related with Facebook's create-react-app generator.   *
*                                                            *
*  For more information, please visit                        *
*  https://github.com/facebook/create-react-app/issues/11174 *
*                                                            * 
**************************************************************`);
