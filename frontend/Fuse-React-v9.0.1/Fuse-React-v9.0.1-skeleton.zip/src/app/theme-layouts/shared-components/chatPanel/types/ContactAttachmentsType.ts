/**
 * ContactAttachmentsType
 */
export type ContactAttachmentsType = {
	media: string[];
	docs: string[];
	links: string[];
};
