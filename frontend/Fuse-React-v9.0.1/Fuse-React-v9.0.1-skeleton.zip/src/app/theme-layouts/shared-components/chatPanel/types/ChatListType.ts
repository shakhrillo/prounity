import { ChatListItemType } from './ChatListItemType';

/**
 * Chat list type
 */
export type ChatListType = ChatListItemType[];
