/**
 * Contact status type
 */
export type ContactStatusType = 'online' | 'do-not-disturb' | 'away' | 'offline';
